import tester.*;
public interface IFunc<A, R> {
  R apply(A arg);
}
